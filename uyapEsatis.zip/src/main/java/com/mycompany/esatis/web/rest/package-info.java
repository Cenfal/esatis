/**
 * Spring MVC REST controllers.
 */
package com.mycompany.esatis.web.rest;
