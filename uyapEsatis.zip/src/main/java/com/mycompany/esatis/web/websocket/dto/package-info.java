/**
 * Data Access Objects used by WebSocket services.
 */
package com.mycompany.esatis.web.websocket.dto;
