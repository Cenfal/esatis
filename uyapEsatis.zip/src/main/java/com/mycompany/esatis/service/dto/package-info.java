/**
 * Data Transfer Objects.
 */
package com.mycompany.esatis.service.dto;
