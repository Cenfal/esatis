/**
 * Service layer beans.
 */
package com.mycompany.esatis.service;
