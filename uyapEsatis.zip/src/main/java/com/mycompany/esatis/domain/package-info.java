/**
 * JPA domain objects.
 */
package com.mycompany.esatis.domain;
